# cafeComVogal

**cafeComVogal** é um pacote, cujo intuito é o uso da função
**vogais()**. Essa é responsável por encontrar todas as vogais de uma string.

# Função

* `vogais(stringCompleta: str)` - Recebe uma string e
retorna um dicionário. Uma de suas chaves é a `vogais`, a qual contém uma lista das 
vogais existentes na string passada como parâmetro na função, e a outra é a
`vogais_com_indice`, a qual contém uma lista com as vogais e seus respectivos indices na 
string.